class Section4:

    @staticmethod
    def get_problem_13_answer():
        return 0  # Return number of activation records

    @staticmethod
    def get_problem_14_answer():
        # Replace the values of n, x, and y with your answer
        n = 0
        x = 0
        y = 0
        return n, x, y

    @staticmethod
    def get_problem_15_answer():
        return 0  # If you think the answer to the problem is option n, return n


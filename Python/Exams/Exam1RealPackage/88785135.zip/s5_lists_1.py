class Section5:

    @staticmethod
    def get_problem_16_answer():
        return 3  # Return the integer printed by 'Print statement 0'

    @staticmethod
    def get_problem_17_answer():
        return 6  # Return the integer printed by 'Print statement 1'

    @staticmethod
    def get_problem_18_answer():
        return 3  # Return the integer printed by 'Print statement 2'

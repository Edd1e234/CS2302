class Section2:

    @staticmethod
    def get_problem_2_answer(): # DONE
        return 0  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_3_answer(): # DONE
        return 0  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_4_answer():
        return 3  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_5_answer():
        return 2  # If you think the answer to the problem is option n, return n

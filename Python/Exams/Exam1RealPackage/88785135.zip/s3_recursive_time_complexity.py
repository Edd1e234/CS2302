class Section3:

    @staticmethod
    def get_problem_6_answer():
        # Replace the values of a, b, and k with your answer
        a = 1
        b = 4
        k = 1

        return a, b, k

    @staticmethod
    def get_problem_7_answer():
        # Replace the values of a, b, and k with your answer
        a = 6
        b = 2
        k = 0

        return a, b, k

    @staticmethod
    def get_problem_8_answer():
        # Replace the values of a, b, and k with your answer
        a = 2
        b = 8
        k = 1

        return a, b, k

    @staticmethod
    def get_problem_9_answer():
        return 4  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_10_answer():
        return 5  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_11_answer():
        return 0  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_12_answer():
        return 260  # Return an integer

class MultipleChoiceSection:

    @staticmethod
    def get_problem_1_answer():

        return 3  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_2_answer():

        return 5  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_3_answer():

        return 6  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_4_answer():
        return 0  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_5_answer():
        return 0  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_6_answer():

        return 0  # If you think the answer to the problem is option n, return n


class Section3:

    @staticmethod
    def get_problem_6_answer():
        # Replace the values of a, b, and k with your answer
        a = 0
        b = 0
        k = 0

        return a, b, k

    @staticmethod
    def get_problem_7_answer():
        # Replace the values of a, b, and k with your answer
        a = 8
        b = 2
        k = 0

        return a, b, k

    @staticmethod
    def get_problem_8_answer():
        # Replace the values of a, b, and k with your answer
        a = 0
        b = 0
        k = 0

        return a, b, k

    @staticmethod
    def get_problem_9_answer():
        return 0  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_10_answer():
        return 0  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_11_answer():
        return 0  # If you think the answer to the problem is option n, return n

    @staticmethod
    def get_problem_12_answer():
        return 40  # Return an integer

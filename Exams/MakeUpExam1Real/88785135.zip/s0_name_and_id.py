class Section0:
    student_last_name = "Garcia"
    student_first_name = "Eduardo"
    utep_id = "88785135"
    class_secret = "82"

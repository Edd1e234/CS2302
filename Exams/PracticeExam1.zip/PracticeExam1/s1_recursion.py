class Section1:

    # Given a non-negative int n, return the number
    # of digits in n that are less than or equal
    # to 5 - Use recursion - no loops.

    # Example1: count(285) -> 2
    # Example2: count(565891) -> 3

    @staticmethod
    def count(n):
        return 0


def main():
    test_result = Section1.count(1273)

    print("test_result = ", test_result)


if __name__ == "__main__":
    main()

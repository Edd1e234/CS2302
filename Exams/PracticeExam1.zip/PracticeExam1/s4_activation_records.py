class Section4:

    @staticmethod
    def get_problem_13_answer():
        return 0  # Return number of activation records

    @staticmethod
    def get_problem_14_answer():
        return 0  # Return value of n activation record #2

    @staticmethod
    def get_problem_15_answer():
        return 0  # If you think the answer to the problem is option n, return n


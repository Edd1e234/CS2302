class Section0:
    student_last_name = "Your last name goes here"
    student_first_name = "Your first name goes here"
    utep_id = "Your UTEP ID goes here"
